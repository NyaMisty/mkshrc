# .mkshrc
Systemlessly mksh.rc for better Terminal experience. Termux environment is also useable.

